import React, {Component,PropTypes} from 'react';
import styles from './VtxTree.less';

import { Tree , Input , Tooltip } from 'antd';

const TreeNode = Tree.TreeNode;
const Search = Input.Search;


class VtxTree extends React.Component {
	constructor(props){
		super(props);
		this.state = {
			isExpandAll: props.isExpandAll || 'other',
			autoExpandParent: ('autoExpandParent' in props?props.autoExpandParent : true),
        	expandedKeys: props.expandedKeys,
        	selectedKeys: props.selectedKeys,
        	data: props.data,
        	onLoad: props.onLoad,
        	inputValue: '',
		}
		// console.log(props);
	}
	/*
		vtxTree事件处理
	 */
	//右击事件
	onRightClick({event,node}){
		let t = this;
		// console.log(node);
		if('onRightClick' in t.props && typeof(t.props.onRightClick) === 'function'){
			let key = node.props.eventKey;
			let treeNode = t.getTreeNodeByKey(t.props.data,key);
			t.props.onRightClick({event,key,treeNode});
		}
	}
	//点击事件(checkable为true时,效果和onCheck相同,即为多选事件)
	onSelect(selectedKeys, e){
		// console.log(selectedKeys)
		// console.log(e)
		let t = this;
		let _tree = t.props;
		let key = e.node.props.eventKey;
		//同时为true时,onSelect事件执行onCheck方法
		if(_tree.checkable && _tree.isGangedChecked){
			e.node.onCheck();
			return false;
		}
		let treeNode = t.getTreeNodeByKey(t.props.data,key);
		//无关联的点击事件
		if('onClick' in t.props && typeof(t.props.onClick) === 'function'){
			t.setState({
				selectedKeys
			})
			_tree.onClick({key,selectedKeys,treeNode});
		}
	}
	//复选框存在时的多选事件
	onCheck(checkedKeys,e){
		// console.log(checkedKeys)
		// console.log(e)
		let t = this;
		let _tree = t.props;
		let key = e.node.props.eventKey;
		let isChecked = e.node.props.checked;
		let treeNode;
		let leafNode = [];
		//遍历获取所有选中叶子节点 和 当前点击的节点
		let getNodes = (item,index)=>{
			if(item.key === key){
				treeNode = item;
			}
			checkedKeys.map((itemK,indexK)=>{
				if(item.key === itemK && item.isLeaf && !(item.disabled || item.disableCheckbox)){
					leafNode.push(item);
				}
			});
			if(t.isArray(item.children)){
				t.traverse(item.children,getNodes);
			}
		}
		t.traverse(_tree.data,getNodes);
		// console.log(treeNode)
		// console.log(leafNode)
		if('onCheck' in t.props && typeof(t.props.onCheck) === 'function'){
			_tree.onCheck({key,isChecked,checkedKeys,treeNode,leafNode});
		}
	}

	//展开和收起事件
	onExpand(expandedKeys, e){
		let t = this;
		if('onExpand' in t.props && typeof(t.props.onExpand) === 'function'){
			let key = e.node.props.eventKey;
			let isExpand = e.expanded;
			let treeNode = t.getTreeNodeByKey(t.props.data,key);
			t.props.onExpand({key,expandedKeys,isExpand,treeNode});
		}else{
			t.setState({
				isExpandAll: 'other',
				expandedKeys: expandedKeys,
				autoExpandParent: false,
			});
		}
	}
	//动态加载树数据
	onLoadData(node){
		// console.log(node)
		let t = this;
		let key = node.props.eventKey;
		let isExpand = node.props.expanded;
		let treeNode = t.getTreeNodeByKey(t.props.data,key);
		return new Promise((resolve) => {
			this.props.onLoadData({key,treeNode,isExpand,resolve});
		})
	}
	//搜索框onchange事件
	filtrateTree(val){
		let t = this;
		let keys = t.getKeysbySearch(val);
		t.setState({
			inputValue: val,
			expandedKeys: keys,
			isExpandAll: 'other',
			autoExpandParent: true
		})
	}
	//搜索框onchange事件
	onChange(e){
		let t = this;
		let val = e.target.value;
		//内部记录搜索框输入的内容
		t.setState({
			inputValue: e.target.value,
		});
		let keys = t.getKeysbySearch(val);
		//使用者控制onChange事件
		if(!!t.props.searchInput && 'onChange' in t.props.searchInput){
			t.props.searchInput.onChange({val,keys});
			//手动控制事件后,默认事件被阻止
			return false;
		}
		t.setState({
			expandedKeys: keys,
			isExpandAll: 'other',
			autoExpandParent: true
		})
	}
	//搜索框onsubmit确定事件
	onSubmit(){
		let t = this;
		let val = t.state.inputValue;
		let keys = t.getKeysbySearch(val);
		//使用者控制onSubmit事件
		if(!!t.props.searchInput && 'onSubmit' in t.props.searchInput){
			t.props.searchInput.onSubmit({val,keys});
			//手动控制事件后,默认事件被阻止
			return false;
		}
		t.setState({
			expandedKeys: keys,
			isExpandAll: 'other',
			autoExpandParent: true
		})
	}
	/*
		公共方法
	 */
	//通过searchInput找出对应的keys
	getKeysbySearch(val){
		let t = this;
		let data = t.props.data;
		let keys = [];
		let getKeys = function (item,index) {
			if(item.name.toString().toUpperCase().indexOf(val.toString().toUpperCase()) > -1){
				keys.push(item.key);
			}
			if(('children' in item) && t.isArray(item.children)){
				t.traverse(item.children,getKeys);
			}
		}
		t.traverse(data,getKeys);
		return keys;
	}
	//通过key获取对应的treeNode
	getTreeNodeByKey(data,key){
		let t = this;
		let treeNode;
		let loop = (item,index)=>{
			if(item.key == key){
				treeNode = item;
				return true;
			}
			if('children' in item && t.isArray(item.children)){
				t.traverse(item.children,loop);
			}
		}
		t.traverse(data,loop);
		return treeNode;
	}
	//遍历tree数据方法
	traverse(ary,backcall){
		ary.map((item,index)=>{
			backcall(item,index);
		});
	}
	//判断对应参数是否是数组
	isArray(ary){
		return Object.prototype.toString.call(ary) === '[object Array]';
	}
	//获取所有叶子节点(onload事件)
	getLeafKeys(){
		let t = this;
		let leafNode = [];
		let leafKeys = [];
		let getNodes = (item,index)=>{
			if(item.isLeaf){
				leafNode.push(item);
				leafKeys.push(item.key);
			}
			if(t.isArray(item.children)){
				t.traverse(item.children,getNodes);
			}
		}
		t.traverse(t.state.data,getNodes);
		return {leafNode,leafKeys};
	}
	render(){
		let t = this;
		let _tree = t.props;
		//antd-tree树参数
		let TreeProps = {
			multiple: _tree.multiple || false, //true可以点击多个节点
			checkable: _tree.checkable || false, //true时有复选框
			autoExpandParent: t.state.autoExpandParent,//是否自动展开父节点

			onSelect: t.onSelect.bind(t),//点击节点事件 (checkable时效果和onCheck相同,即为多选事件)
			onCheck: t.onCheck.bind(t),//在checkable为true时点击复选框事件
			onExpand: t.onExpand.bind(t),//展开和收起节点事件
		}
		//右击事件
		if('onRightClick' in _tree && typeof(_tree.onRightClick) === 'function'){
			TreeProps.onRightClick = t.onRightClick.bind(t); 
		}
		//可控显示选中节点
		if('selectedKeys' in _tree){
			if(t.isArray(_tree.selectedKeys))
				TreeProps.selectedKeys = t.state.selectedKeys || [];
			else
				console.error('warn: selectedKeys: Data type error!');
		}
		//动态加载树数据
		if('checkedKeys' in _tree){
			if(t.isArray(_tree.checkedKeys))
				TreeProps.checkedKeys = _tree.checkedKeys || [];
			else
				console.error('warn: checkedKeys: Data type error!');
		}
		//动态加载树数据
		if('onLoadData' in _tree){
			if(typeof(_tree.onLoadData) === 'function')
				TreeProps.loadData = t.onLoadData.bind(t);
			else
				console.error('warn: VtxTree data: onLoadData is not a function!');
		}
		//树展开功能
		if('isExpandAll' in _tree && t.state.isExpandAll === 'openAll'){//（受控）展开全部节点
			let ary = [];
			let isLeaf = (item,index)=>{
				//判断是否是叶子节点 (是叶子节点,记录下节点key,不是则继续往下找)
				ary.push(item.key);
				if('children' in item 
						&& typeof(item.children) === 'object' 
							&& item.children.length){
					t.traverse(item.children,isLeaf);
				}
			}
			t.traverse(_tree.data,isLeaf);
			TreeProps.expandedKeys = ary;
		}else if('isExpandAll' in _tree && t.state.isExpandAll === 'closeAll'){//（受控）收起全部节点
			TreeProps.expandedKeys = [];
		}else if(t.state.isExpandAll === 'other'){//（受控）展开树节点
			TreeProps.expandedKeys = t.state.expandedKeys || [];
		}else if('expandedKeys' in _tree){//（受控）展开指定的树节点
			TreeProps.expandedKeys = t.state.expandedKeys || [];
		}
		//加载节点树
		let loop = (data) => {
			//检索传入树的数据格式是否正确
			if(typeof(data) !== 'object' || (!data.length && data.length !== 0)){
				console.error('warn: VtxTree data: Data type error!');
				return false;
			}
			let render = data.map((item,index)=>{
				let searchValue = t.state.inputValue;
				let name = item.name;
				//搜索框搜索文字高亮功能
				if(!!_tree.isShowSearchInput && searchValue.length > 0){
			      	const indexn = item.name.search(t.state.inputValue);
			      	const beforeStr = item.name.substr(0,indexn);
			      	const afterStr = item.name.substr(indexn + searchValue.length);
			      	name = (
			      		indexn != -1?
			      			<span>
			      				{beforeStr}
						        <span style={{ color: (!!_tree.searchInput ? _tree.searchInput.color || '#f50': '#f50'),'font-weight':'bold' }}>{searchValue}</span>
						        {afterStr}
			      			</span>
				      		:
				      		<span>{name}</span>
			      		);

				}
				let _title = (
					!!item.icon ?
					<div className={styles.text_ellipsis} style={{maxWidth: `${t.props.width || 100}px`}}>
						<i className={`iconfont ${item.icon} ${item.iconClassName || ''}`}
							style={{'verticalAlign':'middle','marginRight':'4px'}}></i>
						{name}
					</div>
					:
					(
						!!item.img ?
						<div className={styles.text_ellipsis} style={{maxWidth: `${t.props.width || 100}px`}}>
							<img src={item.img} alt=""
								style={{'width':'16px','height':'16px','verticalAlign':'middle','marginRight':'4px'}}/>
							{name}
						</div>
						:
						<div className={styles.text_ellipsis} style={{maxWidth: `${t.props.width || 100}px`}}>
							{name}
						</div>
					)
				);
				_title = (
					<Tooltip placement="topLeft" title={name}>
        				{_title}
	      			</Tooltip>
		      	);
				let TreeNodeProps = {
					disabled: item.disabled || (_tree.disabledAll?true:false),
					disableCheckbox:  item.disableCheckbox || (_tree.disableCheckboxAll?true:false),
					title: _title,
					key: item.key,
					isLeaf: item.isLeaf || false
				}
				return(
					<TreeNode {...TreeNodeProps} >
					{
						//子节点数据处理,避免数据异常
						(('children' in item) && t.isArray(item.children))?
						loop(item.children):''
					}
					</TreeNode>
				);
			});
			return render;
		} 
		return(
			<div>
				{
					!_tree.isShowSearchInput?''
					:(!!_tree.searchInput && 'render' in _tree.searchInput)
						?_tree.searchInput.render(t.onChange.bind(t),t.onSubmit.bind(t))
						:<Search style={{ width: 200 }} placeholder="Search" onChange={t.onChange.bind(t)} onSearch={t.onSubmit.bind(t)}/>
				}
				{
					_tree.data.length
					?<Tree {...TreeProps}>{loop(_tree.data)}</Tree>
					:'loading tree'
				}
			</div>
		);
	}
	componentDidMount(){
		let t = this;
		//树加载完后回调事件
		let keys = t.getLeafKeys();
		if(!!t.state.onLoad && !!t.state.data[0])
			t.state.onLoad({leafNode:keys.leafNode,leafKeys:keys.leafKeys});
	}
	componentDidUpdate(prevProps, prevState) {//重新渲染结束
		let t = this;
		//加载完后回调事件
		let keys = t.getLeafKeys();
		if(!!t.state.onLoad && !!t.state.data[0])
			t.state.onLoad({leafNode:keys.leafNode,leafKeys:keys.leafKeys});
    }
	componentWillReceiveProps(nextProps) {//已加载组件，收到新的参数时调用
    	let t = this;
    	t.setState({
    		isExpandAll : (nextProps.isExpandAll?nextProps.isExpandAll:t.state.isExpandAll),
    		selectedKeys: (nextProps.selectedKeys?nextProps.selectedKeys:t.state.selectedKeys),
    		expandedKeys: (nextProps.expandedKeys?nextProps.expandedKeys:t.state.expandedKeys),
    		autoExpandParent: ('autoExpandParent' in nextProps?nextProps.autoExpandParent:t.state.autoExpandParent),
    		data: (nextProps.data?nextProps.data:t.state.data),
    		onLoad: nextProps.onLoad
    	})
    }
}

export default VtxTree;
